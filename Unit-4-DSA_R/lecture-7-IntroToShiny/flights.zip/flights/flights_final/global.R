
flights <- read.csv(file = "../flights/flights14.csv")
